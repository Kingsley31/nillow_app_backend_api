module.exports.GENDER_SERVICE_TYPES = ["women", "men", "both"];

module.exports.GENDER_SERVICE_TYPE_MEN = "men";
module.exports.GENDER_SERVICE_TYPE_WOMEN = "women";
module.exports.GENDER_SERVICE_TYPE_BOTH = "both";



module.exports.SERVICE_PROVIDER_TYPES = ["nilow-plus", "nilow-indie"];

module.exports.SERVICE_PROVIDER_TYPE_NILOW_PLUS = "nilow-plus";
module.exports.SERVICE_PROVIDER_TYPE_NILOW_INDIE = "nilow-indie";

module.exports.VENDOR_SERVICE_STATUS_TYPES = ["public", "private"];
module.exports.VENDOR_SERVICE_STATUS_TYPE_PUBLIC = "public";
module.exports.VENDOR_SERVICE_STATUS_TYPE_PRIVATE = "private";


module.exports.LOCATION_PREFERENCE_TYPES = ["on", "off"];
module.exports.LOCATION_PREFERENCE_TYPE_ON = "on";
module.exports.LOCATION_PREFERENCE_TYPE_OFF = "off";